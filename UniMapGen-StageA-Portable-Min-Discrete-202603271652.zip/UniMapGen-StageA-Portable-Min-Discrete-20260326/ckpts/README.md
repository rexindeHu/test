Place the base Qwen3-VL model under:

- `ckpts/modelscope/Qwen3-VL-4B-Instruct/`

Or set `MODEL_DIR` to any other local path that already contains the model files.
